#!/usr/bin/env python3


import json
import sys

import tensorflow as tf


class Config:
    def __init__(
            self,
            input_dim,
            num_inputs,
            num_classes,
            output_points_fw,
            output_points_bw,
            scope):
        self.input_dim = input_dim
        self.num_classes = num_classes
        self.num_inputs = num_inputs
        self.output_points_fw = output_points_fw
        self.output_points_bw = output_points_bw
        self.num_outputs = self.get_num_outputs()
        self.rnn_cell_type = 'GRU'
        self.num_units = 40
        self.num_layers = 4
        self.feature_size = 10
        self.scope = scope


    def get_num_outputs(self):
        if self.output_points_fw is None:
            return 0
        return len(self.output_points_fw)


    @staticmethod
    def load_from_json(json_file):
        config = Config(None, None, None, None, None, None)
        with open(json_file, 'r') as fp:
            param_dict = json.load(fp)
        for key in param_dict.keys():
            config.__dict__[key] = param_dict[key]
        config.num_outputs = config.get_num_outputs()
        return config


class Model:
    def __init__(self):
        pass


    def inference(
            self,
            one_hot_haplotypes,
            config_list,
            model_file_prefix,
            num_threads=1):
        with tf.Graph().as_default():
            tf_dataset = tf.data.Dataset.from_tensor_slices(one_hot_haplotypes)
            tf_dataset = tf_dataset.batch(len(one_hot_haplotypes))
            iterator = tf_dataset.make_one_shot_iterator()
            next_inputs = iterator.get_next()

            if len(config_list) == 1:
                logits = self._setup_model(next_inputs, config)
            else:
                logits = self._setup_hybrid_model(next_inputs, *config_list)

            config = config_list[0]
            predictions = tf.reshape(
                tf.nn.softmax(tf.concat(logits, 0)),
                shape=[config.num_outputs, -1, config.num_classes])

            tf_config = tf.ConfigProto(
                intra_op_parallelism_threads=num_threads)
            with tf.Session(config=tf_config) as sess:
                tf.train.Saver().restore(sess, model_file_prefix)
                predicted_values = sess.run(predictions)

        return predicted_values


    def _setup_model(self, inputs, config):
        with tf.variable_scope(config.scope):
            input_list = tf.unstack(inputs, config.num_inputs, 1)
            self._features = tf.Variable(
                tf.zeros([config.num_inputs, 2, config.feature_size]),
                trainable=False, name='features')

            rnn_inputs = []
            for i in range(config.num_inputs):
                if config.feature_size == 0:
                    rnn_inputs.append(input_list[i])
                else:
                    rnn_input = tf.matmul(input_list[i], self._features[i])
                    rnn_inputs.append(rnn_input)

            rnn_fw_cells = [
                self._make_rnn_cell(config, i)
                for i in range(config.num_layers)
            ]
            rnn_bw_cells = [
                self._make_rnn_cell(config, i)
                for i in range(config.num_layers)
            ]

            if config.num_layers > 1:
                rnn_fw_cell = tf.nn.rnn_cell.MultiRNNCell(
                    rnn_fw_cells, state_is_tuple=True)
                rnn_bw_cell = tf.nn.rnn_cell.MultiRNNCell(
                    rnn_bw_cells, state_is_tuple=True)
            else:
                rnn_fw_cell = rnn_fw_cells[0]
                rnn_bw_cell = rnn_bw_cells[0]

            fw_end = config.output_points_fw[-1]
            bw_start = config.output_points_bw[0]

            outputs_fw = [None] * config.num_inputs
            outputs_bw = [None] * config.num_inputs

            if fw_end is not None:
                inputs_fw = rnn_inputs[: fw_end + 1]
                outputs, _ = self._static_rnn(rnn_fw_cell, inputs_fw, 'rnn_fw')
                for t in range(fw_end + 1):
                    outputs_fw[t] = outputs[t]

            if bw_start is not None:
                inputs_bw = [
                    rnn_inputs[i]
                    for i in range(config.num_inputs - 1, bw_start - 1, -1)
                ]
                outputs, _ = self._static_rnn(rnn_bw_cell, inputs_bw, 'rnn_bw')
                for i, t in enumerate(
                    range(config.num_inputs - 1, bw_start - 1, -1)):
                    outputs_bw[t] = outputs[i]

            logit_list = []
            for i, (t_fw, t_bw) in enumerate(
                zip(config.output_points_fw, config.output_points_bw)):
                if t_fw is None:
                    rnn_output = outputs_bw[t_bw]
                    output_dim = config.num_units
                elif t_bw is None:
                    rnn_output = outputs_fw[t_fw]
                    output_dim = config.num_units
                else:
                    rnn_output = tf.concat(
                        [outputs_fw[t_fw], outputs_bw[t_bw]], axis=1)
                    output_dim = 2 * config.num_units

                num_classes = config.num_classes
                W = tf.Variable(
                    tf.truncated_normal([output_dim, num_classes], stddev=1.0),
                    name='weight_%d' % (i + 1))
                b = tf.Variable(
                    tf.truncated_normal([num_classes], stddev=0.1),
                    name='bias_%d' % (i + 1))

                logit = tf.matmul(rnn_output, W) + b
                logit_list.append(logit)

            return logit_list


    def _make_rnn_cell(self, config, layer_number):
        if config.rnn_cell_type == 'GRU':
            cell = tf.nn.rnn_cell.GRUCell(config.num_units)
        elif config.rnn_cell_type == 'LSTM':
            cell = tf.nn.rnn_cell.LSTMCell(
                config.num_units, forget_bias=1.0,
                state_is_tuple=True)
        else:
            print('Unsupported RNN cell type: ' + self.rnn_cell_type,
                  file=sys.stderr)
            sys.exit(0)
        return cell


    def _static_rnn(self, rnn_cell, inputs, scope):
        batch_size = tf.shape(inputs[0])[0]
        state = rnn_cell.zero_state(batch_size, tf.float32)
        outputs = []
        with tf.variable_scope(scope):
            for t, input_ in enumerate(inputs):
                if t > 0:
                    tf.get_variable_scope().reuse_variables()
                output, state = rnn_cell(input_, state)
                outputs.append(output)
        return outputs, state


    def _setup_hybrid_model(self, inputs, config1, config2):
        logits1 = self._setup_model(inputs, config1)
        logits2 = self._setup_model(inputs, config2)
        input_list = [
            tf.concat([logit1, logit2], 1)
            for logit1, logit2 in zip(logits1, logits2)
        ]
        logit_list = []
        with tf.variable_scope('common'):
            num_classes = config1.num_classes
            for i, input_ in enumerate(input_list):
                W = tf.Variable(
                    tf.truncated_normal(
                        [num_classes * 2, num_classes], stddev=1.0),
                    name='weight_%d' % (i + 1))
                b = tf.Variable(
                    tf.truncated_normal([num_classes], stddev=0.1),
                    name='bias_%d' % (i + 1))
                logit = tf.matmul(input_, W) + b
                logit_list.append(logit)
        return logit_list
