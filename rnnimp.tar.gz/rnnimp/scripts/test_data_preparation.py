#!/usr/bin/env python3


from contextlib import contextmanager
import gzip
import os
import re
import shutil
import subprocess
import sys


def system(command):
    subprocess.call(command, shell=True)


def system_with_stdout(command):
    proc = subprocess.Popen(
            command,
            stdin  = subprocess.PIPE,
            stdout = subprocess.PIPE,
            stderr = subprocess.PIPE,
            shell  = True)
    lines = []
    for line in proc.stdout:
        lines.append(line.decode('utf-8').strip())
    return lines


def mkdir(dirname):
    if dirname.strip() != '':
        os.makedirs(dirname, exist_ok=True)


def print_error(error_message=None):
    if error_message == None:
        print(file=sys.stderr)
    else:
        print(error_message, file=sys.stderr)


@contextmanager
def reading(filename):
    root, ext = os.path.splitext(filename)
    fp = gzip.open(filename, 'rt') if ext == '.gz' else open(filename, 'rt')
    try:
        yield fp
    finally:
        fp.close()


@contextmanager
def writing(filename):
    root, ext = os.path.splitext(filename)
    fp = gzip.open(filename, 'wt') if ext == '.gz' else open(filename, 'wt')
    try:
        yield fp
    finally:
        fp.close()


def complement_base(base):
    if base == 'A':
        return 'T'
    if base == 'T':
        return 'A'
    if base == 'G':
        return 'C'
    if base == 'C':
        return 'G'
    return 'N'


def get_sequence(region, hg19_fasta_file):
    command = 'samtools faidx {:s} {:s}'.format(hg19_fasta_file, region)
    lines = system_with_stdout(command)
    sequence = ''.join(lines[1:])
    return sequence


def align(ref_seq, seq):
    for i in range(len(ref_seq) - len(seq)):
        mismatch_flag = False
        for j in range(len(seq)):
            if ref_seq[i + j] != seq[j]:
                mismatch_flag = True
                break
        if not mismatch_flag:
            return i
    return -1


def parse_manifest(manifest_file, chr_num, hg19_fasta_file):
    marker_dict = {}
    with open(manifest_file) as fp:
        for line in fp:
            if line.startswith('[Assay]'):
                break
        items = fp.readline().strip().split(',')
        IlmnStrand_col = items.index('IlmnStrand')
        Chr_col = items.index('Chr')
        MapInfo_col = items.index('MapInfo')
        SNP_col = items.index('SNP')
        SourceStrand_col = items.index('SourceStrand')
        SourceSeq_col = items.index('SourceSeq')
        RefStrand_col = items.index('RefStrand')
        for line in fp:
            if line.startswith('[Controls]'):
                break
            items = line.strip().split(',')
            if items[Chr_col] != chr_num:
                continue
            position = items[MapInfo_col]
            alleles = items[SNP_col][1:-1].split('/')
            if alleles[0] == 'I' or alleles[0] == 'D':
                source_seq = items[SourceSeq_col]
                upstream_seq, a0, a1, downstream_seq = re.split(
                    '[\[\/\]]', source_seq)
                upstream_seq = upstream_seq.upper()
                downstream_seq = downstream_seq.upper()
                if a0 == '-':
                    a0 = ''
                if a1 == '-':
                    a1 = ''
                a0_seq = upstream_seq + a0 + downstream_seq
                a1_seq = upstream_seq + a1 + downstream_seq
                margin = 10
                region_start = int(position) - len(upstream_seq) - margin
                region_end = region_start + margin \
                             + max(len(a0_seq), len(a1_seq)) + margin
                region = 'chr{:s}:{:d}-{:d}'.format(
                    chr_num, region_start, region_end)
                ref_seq = get_sequence(region, hg19_fasta_file)
                a0_align = align(ref_seq, a0_seq)
                a1_align = align(ref_seq, a1_seq)
                indel_position = max(a0_align, a1_align) + len(upstream_seq) \
                                 + region_start - 1
                alleles[0] = upstream_seq[-1] + a0
                alleles[1] = upstream_seq[-1] + a1
                position = str(indel_position)
            else:
                if items[RefStrand_col] == '-':
                    alleles[0] = complement_base(alleles[0])
                    alleles[1] = complement_base(alleles[1])
            if position not in marker_dict:
                marker_dict[position] = []
            marker_dict[position].append(alleles)
    return marker_dict


def set_marker_flags(legend_file, marker_dict, output_file):
    mkdir(os.path.dirname(output_file))
    with reading(legend_file) as fp, \
         writing(output_file) as w_fp:
        w_fp.write(fp.readline().rstrip() + ' array_marker_flag\n')
        for line in fp:
            items = line.rstrip().split()
            position = items[1]
            flag = '0'
            if position in marker_dict:
                a0 = items[2]
                a1 = items[3]
                for alleles in marker_dict[position]:
                    if alleles[0] == a0 and alleles[1] == a1:
                        flag = '1'
                        break
                    if alleles[1] == a0 and alleles[0] == a1:
                        flag = '1'
                        break
            w_fp.write('{:s} {:s}\n'.format(line.rstrip(), flag))


def vcf2haplegend(vcf_file, keep_sample_list, output_prefix):
    def is_missing_genotype(genotype):
        if genotype == '.':
            return True
        if genotype == './.':
            return True
        if genotype == '.|.':
            return True
        return False

    mkdir(os.path.dirname(output_prefix))
    with reading(vcf_file) as fp:
        for line in fp:
            if line.startswith('#CHROM'):
                samples = line.rstrip().split()[9:]
                if keep_sample_list is None:
                    keep_sample_id_list = list(range(len(samples)))
                else:
                    keep_sample_id_list = [
                        samples.index(sample) for sample in keep_sample_list
                        if sample in samples
                    ]
                with open(output_prefix + '.sample', 'wt') as s_fp:
                    s_fp.write('ID_1 ID_2 missing\n')
                    s_fp.write('0 0 0\n')
                    for sample_id in keep_sample_id_list:
                        s_fp.write(
                            '{0:s} {0:s} 0\n'.format(samples[sample_id]))
                break
        sample_size = len(keep_sample_id_list)
        with writing(output_prefix + '.hap.gz') as h_fp, \
             writing(output_prefix + '.legend.gz') as l_fp:
            l_fp.write('id position a0 a1\n')
            allele_id_list = [None] * (2 * sample_size)
            hap_record = [None] * (2 * sample_size)
            for line in fp:
                items = line.rstrip().split()
                chrom = items[0]
                position = items[1]
                snp = items[2]
                ref = items[3]
                alts = items[4].split(',')
                genotypes = items[9:]
                for i, sample_id in enumerate(keep_sample_id_list):
                    genotype = genotypes[sample_id]
                    if is_missing_genotype(genotype):
                        allele_id_list[2 * i] = None
                        allele_id_list[2 * i + 1] = None
                    else:
                        allele_id_pair = map(int, genotype.split('|'))
                    for j, allele_id in enumerate(allele_id_pair):
                        allele_id_list[2 * i + j] = allele_id
                for i, alt in enumerate(alts):
                    if alt == '.' or alt.startswith('<'):
                        continue
                    alt_allele_id = i + 1
                    for j, allele_id in enumerate(allele_id_list):
                        if allele_id is None:
                            hap_record[j] = '?'
                        elif allele_id == alt_allele_id:
                            hap_record[j] = '1'
                        else:
                            hap_record[j] = '0'
                    h_fp.write(' '.join(hap_record))
                    h_fp.write('\n')
                    snp_id = snp
                    if snp_id == '.':
                        snp_id = '{:s}:{:s}:{:s}:{:s}'.format(
                            chrom, position, ref, alt)
                    elif len(alts) >= 2:
                        snp_id += ':{:s}:{:s}'.format(ref, alt)
                    l_fp.write('{:s} {:s} {:s} {:s}\n'.format(
                        snp_id, position, ref, alt))


def prepare_test_hap(hap_file, legend_file, output_prefix):
    array_marker_flag_list = []
    with reading(legend_file) as fp, \
         writing(output_prefix + '.legend.gz') as w_fp:
        line = fp.readline()
        items = line.rstrip().split()
        try:
            array_marker_flag_col = items.index('array_marker_flag')
        except ValueError:
            print_error()
            print_error('Error: Header "array_marker_flag" not found in '
                        + legend_file)
            print_error()
            sys.exit(0)
        w_fp.write(line)
        for line in fp:
            items = line.rstrip().split()
            array_marker_flag = items[array_marker_flag_col] == '1'
            array_marker_flag_list.append(array_marker_flag)
            if array_marker_flag:
                w_fp.write(line)
    with reading(hap_file) as fp, \
         writing(output_prefix + '.hap.gz') as w_fp:
        for i, line in enumerate(fp):
            if array_marker_flag_list[i]:
                w_fp.write(line)


def check_required_software(software_name):
    if os.path.exists(software_name):
        return
    if shutil.which(software_name) is not None:
        if os.path.exists(shutil.which(software_name)):
            return
    print_error()
    print_error('Error: Program "{:s}" not found in PATH'.format(
        software_name))
    print_error()
    sys.exit(0)


def check_required_file(file_path):
    if not os.path.exists(file_path):
        print_error()
        print_error('Error: File "{:s}" not found'.format(file_path))
        print_error('Please put the following file in "org_data" directory:')
        print_error()
        print_error('  ' + os.path.basename(file_path))
        print_error()
        sys.exit(0)


def main():
    hap_prefix = 'example_data/hap/chr22'
    true_hap_prefix = 'example_data/hap/chr22_true'

    test_sample_list_file = 'example_data/hap/test_samples.txt'
    vcf_file = (
        'org_data/ALL.chr22.phase3_shapeit2_mvncall_integrated_v5a.'
        '20130502.genotypes.vcf.gz')
    manifest_file = 'org_data/InfiniumOmni2-5-8v1-4_A1.csv'
    hg19_fasta_file = 'org_data/hg19.fa'

    check_required_software('samtools')
    check_required_file(vcf_file)
    check_required_file(manifest_file)
    check_required_file(hg19_fasta_file)
    keep_sample_list = []
    with open(test_sample_list_file) as fp:
        for line in fp:
            keep_sample_list.append(line.rstrip())
    vcf2haplegend(vcf_file, keep_sample_list, true_hap_prefix)
    marker_dict = parse_manifest(manifest_file, '22', hg19_fasta_file)
    set_marker_flags(
        true_hap_prefix + '.legend.gz', marker_dict,
        true_hap_prefix + '.Omni2.5.legend.gz')
    prepare_test_hap(
        true_hap_prefix + '.hap.gz', true_hap_prefix + '.Omni2.5.legend.gz',
        hap_prefix)


if __name__ == '__main__':
    main()
