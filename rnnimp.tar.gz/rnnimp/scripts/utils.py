#!/usr/bin/env python3


from contextlib import contextmanager
import gzip
import os
import subprocess


def system(command):
    subprocess.call(command, shell=True)


def mkdir(dirname):
    if dirname.strip() != '':
        os.makedirs(dirname, exist_ok=True)


@contextmanager
def reading(filename):
    root, ext = os.path.splitext(filename)
    fp = gzip.open(filename, 'rt') if ext == '.gz' else open(filename, 'rt')
    try:
        yield fp
    finally:
        fp.close()


@contextmanager
def writing(filename):
    root, ext = os.path.splitext(filename)
    fp = gzip.open(filename, 'wt') if ext == '.gz' else open(filename, 'wt')
    try:
        yield fp
    finally:
        fp.close()


def get_item_col(header_items, item_name, filename=None):
    try:
        col = header_items.index(item_name)
    except ValueError:
        error_message = 'header \'{:s}\' not found'.format(item_name)
        if filename is not None:
            error_message += ' in ' + filename
        print(error_message, file=sys.stderr)
        sys.exit(0)
    return col
