#!/usr/bin/env python3


from argparse import ArgumentParser
import os
import sys

import numpy as np

import rnn_model
import utils


class SiteInfo:
    def __init__(self, id, position, a0, a1, a1_freq, array_marker_flag):
        self.id = id
        self.position = position
        self.a0 = a0
        self.a1 = a1
        self.a1_freq = a1_freq
        self.array_marker_flag = array_marker_flag


def load_site_info(legend_file):
    site_info_list = []
    with utils.reading(legend_file) as fp:
        items = fp.readline().rstrip().split()
        id_col = utils.get_item_col(items, 'id', legend_file)
        a0_col = utils.get_item_col(items, 'a0', legend_file)
        a1_col = utils.get_item_col(items, 'a1', legend_file)
        position_col = utils.get_item_col(items, 'position', legend_file)
        marker_flag_col = utils.get_item_col(
            items, 'array_marker_flag', legend_file)
        a1_freq_col = utils.get_item_col(items, 'a1_freq', legend_file)
        for line in fp:
            items = line.rstrip().split()
            site_info = SiteInfo(
                items[id_col], items[position_col], items[a0_col],
                items[a1_col], float(items[a1_freq_col]),
                items[marker_flag_col] == '1')
            site_info_list.append(site_info)
    return site_info_list


def load_data(hap_file, legend_file, site_info_list):
    def one_hot(allele, a1_freq):
        if allele is None:
            return [1.0 - a1_freq, a1_freq]
        return [1 - allele, allele]

    site_info_dict = {}
    marker_site_count = 0
    for site_info in site_info_list:
        if site_info.array_marker_flag:
            site_info.marker_id = marker_site_count
            key = '{:s} {:s} {:s}'.format(
                site_info.position, site_info.a0, site_info.a1)
            site_info_dict[key] = site_info
            marker_site_count += 1

    load_info_list = []
    key_set = set()
    with utils.reading(legend_file) as fp:
        items = fp.readline().rstrip().split()
        a0_col = utils.get_item_col(items, 'a0', legend_file)
        a1_col = utils.get_item_col(items, 'a1', legend_file)
        position_col = utils.get_item_col(items, 'position', legend_file)
        for line in fp:
            items = line.rstrip().split()
            position = items[position_col]
            a0 = items[a0_col]
            a1 = items[a1_col]
            swap_flag = False
            key = '{:s} {:s} {:s}'.format(position, a0, a1)
            if key not in site_info_dict:
                key = '{:s} {:s} {:s}'.format(position, a1, a0)
                if key not in site_info_dict:
                    load_info_list.append(None)
                    continue
                swap_flag = True
            key_set.add(key)
            site_info = site_info_dict[key]
            marker_id = site_info.marker_id
            a1_freq = site_info.a1_freq
            load_info_list.append([marker_id, swap_flag, a1_freq])
    sample_size = 0
    with utils.reading(hap_file) as fp:
        items = fp.readline().rstrip().split()
        sample_size = len(items)
    haplotype_list = [[None] * marker_site_count for _ in range(sample_size)]
    with utils.reading(hap_file) as fp:
        for i, line in enumerate(fp):
            load_info = load_info_list[i]
            if load_info is None:
                continue
            items = line.rstrip().split()
            marker_id, swap_flag, a1_freq = load_info
            for item, haplotype in zip(items, haplotype_list):
                allele = None
                if item != 'NA':
                    allele = int(item)
                    if swap_flag:
                        allele = 1 - allele
                haplotype[marker_id] = one_hot(allele, a1_freq)
    for key in site_info_dict.keys():
        if key not in key_set:
            site_info = site_info_dict[key]
            marker_id = site_info.marker_id
            one_hot_value = one_hot(None, site_info.a1_freq)
            for haplotype in haplotype_list:
                haplotype[marker_id] = one_hot_value

    return haplotype_list


def write_gen(predictions, imp_site_info_list, output_file):
    utils.mkdir(os.path.dirname(output_file))
    with open(output_file, 'wt') as fp:
        for allele_probs, site_info in zip(predictions, imp_site_info_list):
            sample_size = len(allele_probs) // 2
            values = [0.0] * (3 * sample_size)
            for i in range(sample_size):
                h0 = allele_probs[2 * i]
                h1 = allele_probs[2 * i + 1]
                values[3 * i] = h0[0] * h1[0]
                values[3 * i + 1] = h0[0] * h1[1] + h0[1] * h1[0]
                values[3 * i + 2] = h0[1] * h1[1]
            line = '--- %s %s %s %s ' \
                   % (site_info.id, site_info.position,
                      site_info.a0, site_info.a1)
            line += ' '.join(map(str, values))
            fp.write(line)
            fp.write('\n')


def imputation(
        input_hap_file,
        input_legend_file,
        config_file_list,
        panel_legend_file,
        model_file_prefix,
        output_prefix,
        num_threads):
    config_list = [
        rnn_model.Config.load_from_json(config_file)
        for config_file in config_file_list
    ]
    site_info_list = load_site_info(panel_legend_file)
    haplotype_list = load_data(
        input_hap_file, input_legend_file, site_info_list)
    model = rnn_model.Model()
    predictions = model.inference(
        np.array(haplotype_list, dtype=np.float32), config_list,
        model_file_prefix, num_threads)
    imp_site_info_list = [
        site_info
        for site_info in site_info_list if not site_info.array_marker_flag
    ]
    write_gen(predictions, imp_site_info_list, output_prefix + '.gen')


def main():
    description = 'imputation'
    parser = ArgumentParser(description=description, add_help=False)
    parser.add_argument('--hap', type=str, required=True,
                        dest='hap_file', help='hap file')
    parser.add_argument('--legend', type=str, required=True,
                        dest='legend_file', help='legend file')
    parser.add_argument('--config-files', type=str, required=True,
                        dest='config_file_list',
                        help='comma separeted config file names')
    parser.add_argument('--panel-legend', type=str, required=True,
                        dest='panel_legend_file', help='panel legend file')
    parser.add_argument('--model-file', type=str, required=True,
                        dest='model_file', help='model file')
    parser.add_argument('--output-prefix', type=str, required=True,
                        dest='output_prefix', help='output prefix')
    parser.add_argument('--num-threads', type=int, default=1,
                        dest='num_threads', help='number of threads')
    args = parser.parse_args()

    imputation(
        args.hap_file, args.legend_file, args.config_file_list.split(','),
        args.panel_legend_file, args.model_file, args.output_prefix,
        args.num_threads)


if __name__ == '__main__':
    main()
