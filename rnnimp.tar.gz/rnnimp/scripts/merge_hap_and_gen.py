#!/usr/bin/env python3


from argparse import ArgumentParser
import os
import sys

import utils


def hap2gen(hap_file, legend_file, output_file):
    def to_gen(allele1, allele2):
        if allele1 == 'NA' or allele2 == 'NA':
            return '0.25 0.5 0.25'
        if allele1 == '0' and allele2 == '0':
            return '1 0 0'
        if allele1 == '0' and allele2 == '1':
            return '0 1 0'
        if allele1 == '1' and allele2 == '0':
            return '0 1 0'
        return '0 0 1'

    with utils.reading(hap_file) as h_fp, \
         utils.reading(legend_file) as l_fp, \
         utils.writing(output_file) as w_fp:
        header_items = l_fp.readline().strip().split()
        id_col = utils.get_item_col(header_items, 'id', legend_file)
        a0_col = utils.get_item_col(header_items, 'a0', legend_file)
        a1_col = utils.get_item_col(header_items, 'a1', legend_file)
        position_col = utils.get_item_col(
            header_items, 'position', legend_file)
        for line in h_fp:
            l_items = l_fp.readline().strip().split()
            a0 = l_items[a0_col]
            a1 = l_items[a1_col]
            snp_name = l_items[id_col]
            position = l_items[position_col]
            items = line.strip().split()
            sample_size = len(items) // 2
            output_line = '--- {:s} {:s} {:s} {:s}'.format(
                snp_name, position, a0, a1)
            for i in range(sample_size):
                output_line += ' '
                output_line += to_gen(items[2 * i], items[2 * i + 1])
            w_fp.write(output_line)
            w_fp.write('\n')


def merge_gen(gen_file1, gen_file2, output_file):
    def get_position(line):
        space_count = 0
        previous_space_position = -1
        for i, c in enumerate(line):
            if c == ' ':
                space_count += 1
                if space_count == 3:
                    return int(line[previous_space_position + 1 : i])
                previous_space_position = i
        return int(line[previous_space_position + 1 :])

    with utils.reading(gen_file1) as fp1, \
         utils.reading(gen_file2) as fp2, \
         utils.writing(output_file) as w_fp:
        position2 = -1
        line2 = None
        for line1 in fp1:
            position1 = get_position(line1)
            if position1 > position2:
                if line2 is not None:
                    w_fp.write(line2)
                    line2 = None
                for line2 in fp2:
                    position2 = get_position(line2)
                    if position1 <= position2:
                        break
                    w_fp.write(line2)
                    line2 = None
            w_fp.write(line1)
        if line2 is not None:
            w_fp.write(line2)
        for line2 in fp2:
            w_fp.write(line2)


def main():
    description = 'merge hap and gen'
    parser = ArgumentParser(description=description, add_help=False)
    parser.add_argument('--hap', type=str,
                        dest='hap_file', required=True,
                        help='hap file')
    parser.add_argument('--legend', type=str,
                        dest='legend_file', required=True,
                        help='legend file')
    parser.add_argument('--gen-file-list', type=str,
                        dest='gen_file_list_file', required=True,
                        help='file for gen file list')
    parser.add_argument('--output-file', type=str,
                        dest='output_file', required=True,
                        help='output file')
    args = parser.parse_args()

    utils.mkdir(os.path.dirname(args.output_file))
    hap2gen(args.hap_file, args.legend_file, args.output_file + '.tmp1')
    gen_file_list = []
    with open(args.gen_file_list_file) as fp:
        for line in fp:
            gen_file_list.append(line.rstrip())
    with open(args.output_file + '.tmp2', 'wt') as w_fp:
        for gen_file in gen_file_list:
            with open(gen_file) as fp:
                for line in fp:
                    w_fp.write(line)
    merge_gen(
        args.output_file + '.tmp1', args.output_file + '.tmp2',
        args.output_file)
    os.remove(args.output_file + '.tmp1')
    os.remove(args.output_file + '.tmp2')


if __name__ == '__main__':
    main()
