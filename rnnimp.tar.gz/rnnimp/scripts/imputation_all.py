#!/usr/bin/env python3


from argparse import ArgumentParser
from collections import namedtuple
import os
import shutil
import sys

import qsub
import utils


PYTHON3 = 'python3'
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


ModelFileInfo = namedtuple(
    'ModelFileInfo', ('model_file', 'legend', 'config1', 'config2'))


def print_error(error_message=None):
    if error_message == None:
        print(file=sys.stderr)
    else:
        print(error_message, file=sys.stderr)


def python3_path_check():
    if os.path.exists(PYTHON3):
        return
    if shutil.which(PYTHON3) is not None:
        if os.path.exists(shutil.which(PYTHON3)):
            return
    print_error()
    print_error('Error: Program "{:s}" not found in PATH'.format(PYTHON3))
    print_error()
    sys.exit(0)


def load_model_file_info_list(model_file_list_file):
    model_file_info_list = []
    with open(model_file_list_file) as fp:
        header_items = fp.readline().rstrip().split()
        model_file_col = utils.get_item_col(
            header_items, 'model_file', model_file_list_file)
        legend_col = utils.get_item_col(
            header_items, 'legend', model_file_list_file)
        config1_col = utils.get_item_col(
            header_items, 'config1', model_file_list_file)
        config2_col = utils.get_item_col(
            header_items, 'config2', model_file_list_file)
        for line in fp:
            items = line.rstrip().split()
            model_file_info = ModelFileInfo(
                items[model_file_col], items[legend_col], items[config1_col],
                items[config2_col])
            model_file_info_list.append(model_file_info)
    return model_file_info_list


def load_lines(filename, header=False):
    header_line = None
    lines = []
    with utils.reading(filename) as fp:
        line_count = 0
        if header:
            header_line = fp.readline().rstrip()
        for line in fp:
            lines.append(line.rstrip())
    return header_line, lines


def split_data(hap_file, legend_file, model_file_info_list, output_prefix):
    utils.mkdir(os.path.dirname(output_prefix))
    _, hap_lines = load_lines(hap_file);
    legend_header, legend_lines = load_lines(legend_file, True);
    header_items = legend_header.split()
    position_col = utils.get_item_col(header_items, 'position', legend_file)
    positions = [int(line.split()[position_col]) for line in legend_lines]
    output_prefix_list = []

    previous_margin_start_index = 0
    max_index = len(positions) - 1
    for i, model_file_info in enumerate(model_file_info_list):
        panel_legend_file = model_file_info.legend
        with utils.reading(panel_legend_file) as fp:
            # skip header
            header_items = fp.readline().rstrip().split()
            position_col = utils.get_item_col(
                header_items, 'position', panel_legend_file)
            marker_flag_col = utils.get_item_col(
                header_items, 'array_marker_flag', panel_legend_file)
            for line in fp:
                items = line.rstrip().split()
                if items[marker_flag_col] == '1':
                    position = int(items[position_col])
                    margin_start_pos = position
                    margin_end_pos = position
                    break
            for line in fp:
                items = line.rstrip().split()
                if items[marker_flag_col] == '1':
                    position = int(items[position_col])
                    margin_end_pos = position
        margin_start_index = max_index
        margin_end_index = max_index
        for index in range(previous_margin_start_index, max_index + 1):
            if positions[index] >= margin_start_pos:
                margin_start_index = index
                break
        for index in range(margin_start_index, max_index + 1):
            if positions[index] > margin_end_pos:
                margin_end_index = index - 1
                break
        previous_margin_start_index = margin_start_index

        output_file = '%s_%d.hap.gz' % (output_prefix, i + 1)
        with utils.writing(output_file) as fp:
            for index in range(margin_start_index, margin_end_index + 1):
                fp.write(hap_lines[index])
                fp.write('\n')
        output_file = '%s_%d.legend.gz' % (output_prefix, i + 1)
        with utils.writing(output_file) as fp:
            fp.write(legend_header)
            fp.write('\n')
            for index in range(margin_start_index, margin_end_index + 1):
                fp.write(legend_lines[index])
                fp.write('\n')
        output_prefix_list.append('%s_%d' % (output_prefix, i + 1))

    return output_prefix_list


def main():
    description = 'imputation all'
    parser = ArgumentParser(description=description, add_help=False)
    parser.add_argument('--hap', type=str, required=True,
                        dest='hap_file', help='hap file')
    parser.add_argument('--legend', type=str, required=True,
                        dest='legend_file', help='legend file')
    parser.add_argument('--model-file-list', type=str, required=True,
                        dest='model_file_list',
                        help='file for model file list')
    parser.add_argument('--output-prefix', type=str, required=True,
                        dest='output_prefix', help='output prefix')
    parser.add_argument('--num-threads', type=int, default=1,
                        dest='num_threads', help='number of threads')
    parser.add_argument('--qsub', action='store_true', default=False,
                        dest='qsub_flag',
                        help='use UGE for computation')
    parser.add_argument('--job-name-prefix', type=str, default='imputation',
                        dest='job_name_prefix', help='prefix of UGE job name')
    parser.add_argument('--memory-size', type=str, default='10GB',
                        dest='memory_size',
                        help='per thread memory size for UGE job')
    args = parser.parse_args()

    python3_path_check()

    model_file_info_list = load_model_file_info_list(args.model_file_list)

    splitted_hap_prefix_list = split_data(
        args.hap_file, args.legend_file, model_file_info_list,
        args.output_prefix)

    for i, splitted_hap_prefix in enumerate(splitted_hap_prefix_list):
        data_basename = os.path.basename(splitted_hap_prefix)
        model_file_info = model_file_info_list[i]
        command = PYTHON3
        command += ' ' + os.path.join(SCRIPT_DIR, 'imputation.py')
        command += ' --hap %s.hap.gz' % (splitted_hap_prefix)
        command += ' --legend %s.legend.gz' % (splitted_hap_prefix)
        command += ' --model-file ' + model_file_info.model_file
        command += ' --panel-legend ' + model_file_info.legend
        command += ' --config-files %s,%s' \
                   % (model_file_info.config1, model_file_info.config2)
        command += ' --output-prefix %s_%d' % (args.output_prefix, i + 1)
        command += ' --num-threads %d' % (args.num_threads)
        if args.qsub_flag:
            job_name = '%s_%d' % (args.job_name_prefix, i + 1)
            output_dir = os.path.dirname(args.output_prefix)
            qsub.qsub(
                command,
                os.path.join(output_dir, 'qsub', 'scripts'),
                os.path.join(output_dir, 'qsub', 'log'),
                job_name,
                qsub.parse_memory_size(args.memory_size),
                args.num_threads)
        else:
            utils.system(command)

    gen_file_list_file = args.output_prefix + '_gen_files.txt'
    with open(gen_file_list_file, 'wt') as fp:
        for i in range(len(splitted_hap_prefix_list)):
            fp.write('%s_%d.gen\n' % (args.output_prefix, i + 1))
    command = PYTHON3
    command += ' ' + os.path.join(SCRIPT_DIR, 'merge_hap_and_gen.py')
    command += ' --hap ' + args.hap_file
    command += ' --legend ' + args.legend_file
    command += ' --gen-file-list ' + gen_file_list_file
    command += ' --output-file %s.gen' % (args.output_prefix)
    if args.qsub_flag:
        job_name = args.job_name_prefix + '_merge'
        output_dir = os.path.dirname(args.output_prefix)
        qsub.qsub(
            command,
            os.path.join(output_dir, 'qsub', 'scripts'),
            os.path.join(output_dir, 'qsub', 'log'),
            job_name, qsub.parse_memory_size(args.memory_size), 1,
            ['-hold_jid %s_*' % (args.job_name_prefix)])
    else:
        utils.system(command)


if __name__ == '__main__':
    main()
