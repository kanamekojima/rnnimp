#!/bin/sh

mkdir -p results
python3 scripts/imputation_all.py \
  --hap example_data/hap/chr22.hap.gz \
  --legend example_data/hap/chr22.legend.gz \
  --model-file-list example_data/model_data/model_files.txt \
  --output-prefix results/chr22
