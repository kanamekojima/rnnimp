#!/usr/bin/env python3


from argparse import ArgumentParser
import os
import subprocess
import sys
import time


def system(command):
    subprocess.call(command, shell=True)


def mkdir(dirname):
    if dirname.strip() != '':
        os.makedirs(dirname, exist_ok=True)


def qsub(
        qsub_command,
        script_dir,
        log_dir,
        job_name,
        memory_usage,
        num_threads,
        additional_options=None):
    mkdir(script_dir)
    mkdir(log_dir)
    script_file = os.path.join(
        script_dir,
        'qsub_{:s}_{:d}_{:d}.sh'.format(
            job_name, int(time.time()), os.getpid()))
    with open(script_file, 'wt') as fp:
        fp.write('#!/bin/bash\n')
        fp.write('#$ -S /bin/bash\n\n')
        fp.write(qsub_command)
        fp.write('\n')
    system('chmod 740 ' + script_file)

    options = [
        '-V',
        '-cwd',
        '-o ' + log_dir,
        '-e ' + log_dir,
        '-N ' + job_name,
        '-l s_vmem=' + memory_usage,
        '-l mem_req=' + memory_usage
    ]
    if num_threads > 1:
        options.append('-pe def_slot {:d}'.format(num_threads))
    if additional_options is not None:
        options.extend(additional_options)
    command = 'qsub {:s} {:s}'.format(' '.join(options), script_file)
    print('command: ' + command)
    system(command)


def parse_memory_size(memory_size):
    if memory_size.endswith('GB'):
        return memory_size[:-1]
    if memory_size.endswith('TB'):
        return '{:d}G'.format(int(memory_size[:-2]) * 1024)
    return '1G'


def main():
    description = 'qsub wrapper'
    parser = ArgumentParser(description=description)
    parser.add_argument('--command', type=str, required=True,
                        dest='command', help='command')
    parser.add_argument('--qsub-dir', type=str, required=True,
                        dest='qsub_dir', help='qsub dir')
    parser.add_argument('--job-name', type=str, required=True,
                        dest='job_name', help='job name')
    parser.add_argument('--memory-size', type=str, default='2GB',
                        dest='memory_size', help='memory size')
    parser.add_argument('--num-threads', type=int, default=1,
                        dest='num_threads', help='number of threads')
    args = parser.parse_args()

    script_dir = os.path.join(args.qsub_dir, 'scripts')
    log_dir = os.path.join(args.qsub_dir, 'log')
    memory_size = parse_memory_size(args.memory_size)
    qsub(
        args.command, script_dir, log_dir, args.job_name, memory_size,
        args.num_threads)


if __name__ == '__main__':
    main()
